package com.v.app;

import com.v.service.AnalyticsService;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        AnalyticsService service = new AnalyticsService();
        Scanner sc = new Scanner(System.in);

        while (true) {

            System.out.println("\n===== Sales & Revenue Analytics System =====");
            System.out.println("1. Total Revenue");
            System.out.println("2. Top Selling Products");
            System.out.println("3. Best Customer");
            System.out.println("4. Monthly Revenue");
            System.out.println("5. Exit");
            System.out.println("6. Insert New Sale");

            System.out.print("Choose: ");
            int choice = sc.nextInt();

            try {
                switch (choice) {
                    case 1 -> service.showTotalRevenue();
                    case 2 -> service.showTopProducts();
                    case 3 -> service.showBestCustomer();
                    case 4 -> service.showMonthlyRevenue();
                    case 5 -> System.exit(0);
                    case 6 -> {

                        System.out.print("Enter Customer ID: ");
                        int customerId = sc.nextInt();

                        System.out.print("Enter Product ID: ");
                        int productId = sc.nextInt();

                        System.out.print("Enter Quantity: ");
                        int quantity = sc.nextInt();

                        sc.nextLine(); // consume newline

                        System.out.print("Enter Sale Date (YYYY-MM-DD): ");
                        String saleDate = sc.nextLine();

                        service.insertNewSale(customerId, productId, quantity, saleDate);
                    }
                    default -> System.out.println("Invalid choice!");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}