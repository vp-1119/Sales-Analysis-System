package com.v.service;

import com.v.db.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AnalyticsService {

    public void showTotalRevenue() throws Exception {

        String query = """
                SELECT SUM(p.price * s.quantity) AS total_revenue
                FROM sales s
                JOIN products p ON s.product_id = p.product_id
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                System.out.println("Total Revenue: ₹" + rs.getDouble("total_revenue"));
            }
        }
    }

    public void showTopProducts() throws Exception {

        String query = """
                SELECT p.product_name, SUM(s.quantity) AS total_sold
                FROM sales s
                JOIN products p ON s.product_id = p.product_id
                GROUP BY p.product_name
                ORDER BY total_sold DESC
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                System.out.println(rs.getString("product_name")
                        + " - Sold: " + rs.getInt("total_sold"));
            }
        }
    }

    public void showBestCustomer() throws Exception {

        String query = """
                SELECT c.name, SUM(p.price * s.quantity) AS total_spent
                FROM sales s
                JOIN customers c ON s.customer_id = c.customer_id
                JOIN products p ON s.product_id = p.product_id
                GROUP BY c.name
                ORDER BY total_spent DESC
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                System.out.println(rs.getString("name")
                        + " - Spent: ₹" + rs.getDouble("total_spent"));
            }
        }
    }
    public void insertNewSale(int customerId, int productId, int quantity, String saleDate) throws Exception {

        String query = """
            INSERT INTO sales (customer_id, product_id, quantity, sale_date)
            VALUES (?, ?, ?, ?)
            """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setInt(1, customerId);
            ps.setInt(2, productId);
            ps.setInt(3, quantity);
            ps.setString(4, saleDate);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("✅ Sale inserted successfully!");
            }
        }
    }

    public void showMonthlyRevenue() throws Exception {

        String query = """
                SELECT MONTH(sale_date) AS month,
                SUM(p.price * s.quantity) AS monthly_revenue
                FROM sales s
                JOIN products p ON s.product_id = p.product_id
                GROUP BY MONTH(sale_date)
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                System.out.println("Month " + rs.getInt("month")
                        + " - Revenue: ₹" + rs.getDouble("monthly_revenue"));
            }
        }
    }
}